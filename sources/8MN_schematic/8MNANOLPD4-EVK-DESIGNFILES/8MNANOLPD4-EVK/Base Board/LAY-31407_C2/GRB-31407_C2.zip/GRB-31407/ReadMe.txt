README for GRB-31407_C2.zip

Company Part Number: 170-31407 REV C2

Date: Fri, 17 Jul 2020 04:48:26 GMT

NXP Semiconductors
6501 William Cannon Drive West
Austin, TX 78735-8598


CAD Engineer
============
Company Contact     : [full_name]
Work Phone          : 512-895-XXXX
Email               : [email]@nxp.com

CAD Manager
===========
Company Contact     : Daniel Kruczek
Work Phone          : 512-895-6081
Email               : daniel.kruczek@nxp.com

Manufacturing Program Manager
=============================
Company Contact     : [full_name]
Work Phone          : 512-895-XXXX
Email               : [email]@nxp.com

Product Engineer
================
Company Contact     : [full_name]
Work Phone          : 512-895-XXXX
Email               : [email]@nxp.com

Design for Manufacturing Engineer
=================================
Company Contact     : Rosalia Gonzalez
Work Phone          : +52(33) 3283-2100 x2267
Email               : HardwareSolutionsCoE-PCB@NXP1.onmicrosoft.com
